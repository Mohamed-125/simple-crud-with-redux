import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "user",
  initialState: [],
  reducers: {
    addUser: (state, action) => {
      return [...state, action.payload];
    },
    deleteUser: (state, action) => {
      const newState = state.filter((user) => user.id !== action.payload.id);
      state = newState;
    },
    updateUser: (state, action) => {}
  }
});

export const { addUser, deleteUser, updateUser } = userSlice.actions;
export default userSlice.reducer;
